import type { ElementType } from 'react';

export type TimeInterval = '1m' | '5m' | '15m' | '60m';

export type MarketSignal = 'buy' | 'sell' | 'neutral';

export interface StatCardProps {
    title: string;
    value: string;
    change: string;
    icon: ElementType;
    color: string;
}

export interface SalesData {
    name: string;
    sales: number;
}

export interface AssetData {
    [key: string]: string | number | { value1: number; value2: number };
    "Asset": string;
    "Último": string | number;
    "Abertura": string | number;
    "Máximo": string | number;
    "Mínimo": string | number;
    "Variação": string;
    "Média": string | number;
    "Nome do Ativo": string;
    "Negócios": string | number;
    "Volume": string | number;
    "Ajuste": string | number;
    "Preço Teórico": string | number;
    "VWAP": string | number;
    "IFR (RSI)": string | number;
    "True Range": string | number;
    "Force Index": { value1: number; value2: number };
    "ADX": number;
    "Bear Power": number;
    "Bull Power": number;
}

export interface IndicatorCardProps {
    title: string;
    data: AssetData;
}

export interface KeyMetricsCardProps {
    data: AssetData;
}

export interface AiInsightCardProps {
    assetData: AssetData;
    timeframe: TimeInterval;
}

export interface AssetDataTableProps {
    data: AssetData;
    timeframe: TimeInterval;
}

export interface ActivityItem {
    id: number;
    name: string;
    email: string;
    amount: string;
    status: 'Success' | 'Pending' | 'Failed';
}

export interface CandlestickData {
    date: string;
    open: number;
    high: number;
    low: number;
    close: number;
    ma?: number;
}

export interface CandlestickChartProps {
    asset: 'WINFUT' | 'WDOFUT';
    data: CandlestickData[];
    timeframe: TimeInterval;
    signal: MarketSignal;
}