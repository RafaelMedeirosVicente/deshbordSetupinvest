import type { AssetData, CandlestickData, TimeInterval } from '../types';

// Helper function to generate mock candlestick data
const generateCandleData = (points: number, intervalMinutes: number, startPrice: number, volatility: number): CandlestickData[] => {
    const dataPoints: Omit<CandlestickData, 'ma'>[] = [];
    let lastClose = startPrice;
    const now = new Date();
    for (let i = points - 1; i >= 0; i--) {
        const date = new Date(now.getTime() - i * intervalMinutes * 60 * 1000);
        const open = lastClose;
        const change = (Math.random() - 0.5) * volatility * open;
        const close = open + change;
        const high = Math.max(open, close) + Math.random() * (volatility / 2) * open;
        const low = Math.min(open, close) - Math.random() * (volatility / 2) * open;
        dataPoints.push({
            date: `${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`,
            open: parseFloat(open.toFixed(2)),
            high: parseFloat(high.toFixed(2)),
            low: parseFloat(low.toFixed(2)),
            close: parseFloat(close.toFixed(2)),
        });
        lastClose = close;
    }
    const smaPeriod = 20;
    const dataWithMa: CandlestickData[] = dataPoints.map((d, i, arr) => {
        if (i < smaPeriod - 1) return { ...d, ma: undefined };
        const sum = arr.slice(i - smaPeriod + 1, i + 1).reduce((acc, val) => acc + val.close, 0);
        return { ...d, ma: parseFloat((sum / smaPeriod).toFixed(2)) };
    });
    return dataWithMa;
};

// Define a base type for asset data that will be consistent across timeframes
interface BaseAssetData {
    "Asset": string;
    "Último": string | number;
    "Abertura": string | number;
    "Máximo": string | number;
    "Mínimo": string | number;
    "Variação": string;
    "Média": string | number;
    "Nome do Ativo": string;
    "Negócios": string | number;
    "Volume": string | number;
    "Ajuste": string | number;
    "Preço Teórico": string | number;
    "VWAP": string | number;
    "True Range": string | number;
}

// Generate comprehensive mock data for all timeframes
const generateTimedAssetData = (base: BaseAssetData): Record<TimeInterval, AssetData> => {
    return {
        '1m': { ...base, "IFR (RSI)": (Math.random() * 40 + 30).toFixed(1), ADX: 15 + Math.random() * 5, "Force Index": {value1: (Math.random() - 0.5) * 1e6, value2: (Math.random() - 0.5) * 1e4}, "Bull Power": 50 + Math.random() * 20, "Bear Power": -30 - Math.random() * 20, Volume: `${(parseFloat(String(base.Volume).replace('B','')) * 0.1).toFixed(2)}B`},
        '5m': { ...base, "IFR (RSI)": (Math.random() * 50 + 25).toFixed(1), ADX: 22 + Math.random() * 8, "Force Index": {value1: (Math.random() - 0.5) * 5e6, value2: (Math.random() - 0.5) * 5e4}, "Bull Power": 120 + Math.random() * 50, "Bear Power": -55 - Math.random() * 30, Volume: `${(parseFloat(String(base.Volume).replace('B','')) * 0.5).toFixed(2)}B` },
        '15m': { ...base, "IFR (RSI)": (Math.random() * 60 + 20).toFixed(1), ADX: 30 + Math.random() * 10, "Force Index": {value1: (Math.random() - 0.5) * 10e6, value2: (Math.random() - 0.5) * 10e4}, "Bull Power": 150 + Math.random() * 60, "Bear Power": -80 - Math.random() * 40, Volume: `${(parseFloat(String(base.Volume).replace('B','')) * 1.0).toFixed(2)}B` },
        '60m': { ...base, "IFR (RSI)": (Math.random() * 70 + 15).toFixed(1), ADX: 40 + Math.random() * 15, "Force Index": {value1: (Math.random() - 0.5) * 20e6, value2: (Math.random() - 0.5) * 20e4}, "Bull Power": 200 + Math.random() * 80, "Bear Power": -100 - Math.random() * 50, Volume: `${(parseFloat(String(base.Volume).replace('B','')) * 2.0).toFixed(2)}B`},
    };
};

export const allWinfutData = generateTimedAssetData({ "Asset": "WINFUT", "Último": "128.550", "Abertura": "128.300", "Máximo": "129.100", "Mínimo": "127.950", "Variação": "+0,25%", "Média": "128.650", "Nome do Ativo": "Ibovespa Mini", "Negócios": "1.234.567", "Volume": "7.89B", "Ajuste": "128.545", "Preço Teórico": "128.552", "VWAP": "128.610", "True Range": "1.150" });
export const allWdofutData = generateTimedAssetData({ "Asset": "WDOFUT", "Último": "5.450,50", "Abertura": "5.430,00", "Máximo": "5.460,00", "Mínimo": "5.425,50", "Variação": "-0,15%", "Média": "5.445,25", "Nome do Ativo": "Dólar Mini", "Negócios": "987.654", "Volume": "4.56B", "Ajuste": "5.449,75", "Preço Teórico": "5.450,10", "VWAP": "5.448,50", "True Range": "34,50" });

export const allMockCandleData = {
    WINFUT: { '1m': generateCandleData(60, 1, 128550, 0.0005), '5m': generateCandleData(60, 5, 128550, 0.001), '15m': generateCandleData(60, 15, 128550, 0.002), '60m': generateCandleData(24, 60, 128550, 0.005) },
    WDOFUT: { '1m': generateCandleData(60, 1, 5450, 0.0008), '5m': generateCandleData(60, 5, 5450, 0.0015), '15m': generateCandleData(60, 15, 5450, 0.003), '60m': generateCandleData(24, 60, 5450, 0.006) },
};
