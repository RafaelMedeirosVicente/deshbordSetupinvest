import { GoogleGenAI } from "@google/genai";
import { AssetData, TimeInterval } from '../types';

if (!process.env.API_KEY) {
    console.warn("API_KEY environment variable not set. AI features will not work.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const model = 'gemini-2.5-flash';

export const generateAssetInsight = async (assetData: AssetData, timeframe: TimeInterval): Promise<string> => {
    if (!process.env.API_KEY) {
        return Promise.resolve("<h4>Erro de Configuração</h4><p>A chave da API não foi configurada. Defina a variável de ambiente API_KEY para usar os recursos de IA.</p>");
    }

    const indicators = `
- **Ativo:** ${assetData['Nome do Ativo']} (${assetData.Asset})
- **Tempo Gráfico:** ${timeframe}
- **Último Preço:** ${assetData['Último']}
- **VWAP:** ${assetData.VWAP}
- **RSI (IFR):** ${assetData['IFR (RSI)']}
- **ADX (Força da Tendência):** ${assetData.ADX}
- **Bull Power:** ${assetData['Bull Power']}
- **Bear Power:** ${assetData['Bear Power']}
- **Force Index:** Principal=${assetData['Force Index'].value1.toFixed(2)}, Secundário=${assetData['Force Index'].value2.toFixed(2)}
    `;

    const prompt = `
        Você é um analista de mercado financeiro sênior, especialista em day trade de mini-índice (WINFUT) e mini-dólar (WDOFUT) na bolsa brasileira (B3).
        Sua tarefa é fornecer uma análise técnica concisa e objetiva com base nos indicadores fornecidos para o tempo gráfico especificado.
        Seu público são traders que precisam de uma interpretação rápida para tomar decisões.

        **Instruções de Formato:**
        - A resposta DEVE ser em HTML simples.
        - Use um cabeçalho <h4> com o título "Análise da IA".
        - Use parágrafos <p> para o texto.
        - Use <strong> para destacar termos importantes como "COMPRA", "VENDA", "FORTE", "FRACA".
        - NÃO inclua <html>, <head>, ou <body> tags.

        **Estrutura da Análise:**
        1.  **Resumo do Momento:** Comece com uma frase concisa sobre o sentimento atual do mercado (ex: "O mercado apresenta um momento de <strong>baixa</strong> com sinais de exaustão...").
        2.  **Análise dos Indicadores:** Interprete a combinação dos indicadores. Por exemplo, como o RSI se relaciona com o ADX? O que o VWAP sugere sobre o preço justo? O que a força (Bull/Bear/Force Index) indica sobre a pressão atual?
        3.  **Conclusão e Cenário:** Termine com um cenário provável para o curto prazo. Evite dar conselhos financeiros diretos. Em vez disso, descreva o cenário (ex: "O cenário sugere cautela. Se o preço se mantiver abaixo do VWAP, a tendência de <strong>baixa</strong> pode continuar. Uma reversão acima do ADX 25 com aumento do Bull Power indicaria uma possível reversão para <strong>alta</strong>.").

        **Dados para Análise:**
        ${indicators}

        Gere a análise agora.
    `;

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                temperature: 0.6,
                topP: 0.95,
            }
        });
        return response.text;
    } catch (error) {
        console.error("Error generating insight from Gemini API:", error);
        if (error instanceof Error) {
            return `<h4>Erro na Análise</h4><p>Ocorreu um erro ao gerar o insight: ${error.message}</p>`;
        }
        return "<h4>Erro na Análise</h4><p>Ocorreu um erro desconhecido ao gerar o insight.</p>";
    }
};