import React from 'react';
import type { MarketSignal } from '../types';

interface SignalLightProps {
    signal: MarketSignal;
}

const SignalLight: React.FC<SignalLightProps> = ({ signal }) => {
    const config = {
        buy: {
            text: 'FORÇA COMPRA',
            colorClasses: 'bg-green-500',
        },
        sell: {
            text: 'FORÇA VENDA',
            colorClasses: 'bg-red-500',
        },
        neutral: {
            text: 'NEUTRO',
            colorClasses: 'bg-slate-500',
        },
    }[signal];

    return (
        <div className="absolute top-4 right-6 bg-slate-900/80 backdrop-blur-sm p-2 rounded-lg shadow-lg flex items-center gap-3 z-10">
            <div className={`relative w-4 h-4 rounded-full ${config.colorClasses}`}>
                 {signal !== 'neutral' && <span className={`absolute inline-flex h-full w-full rounded-full ${config.colorClasses} opacity-75 animate-ping`}></span>}
            </div>
            <p className="text-sm font-bold text-white tracking-wider">{config.text}</p>
        </div>
    );
};

export default SignalLight;
