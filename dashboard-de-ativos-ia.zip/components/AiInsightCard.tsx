import React, { useState, useCallback } from 'react';
import { generateAssetInsight } from '../services/geminiService';
import { AiInsightCardProps } from '../types';
import { SparklesIcon } from '../constants';

const LoadingSpinner: React.FC = () => (
    <div className="flex items-center justify-center space-x-2">
        <div className="w-2 h-2 rounded-full bg-slate-400 animate-pulse [animation-delay:-0.3s]"></div>
        <div className="w-2 h-2 rounded-full bg-slate-400 animate-pulse [animation-delay:-0.15s]"></div>
        <div className="w-2 h-2 rounded-full bg-slate-400 animate-pulse"></div>
    </div>
);

const AiInsightCard: React.FC<AiInsightCardProps> = ({ assetData, timeframe }) => {
    const [insight, setInsight] = useState<string>('<h4>Análise com IA</h4><p>Clique no botão para gerar uma análise técnica dos indicadores atuais para este ativo.</p>');
    const [isLoading, setIsLoading] = useState<boolean>(false);

    const handleGenerateInsight = useCallback(async () => {
        setIsLoading(true);
        setInsight('');
        try {
            const result = await generateAssetInsight(assetData, timeframe);
            setInsight(result);
        } catch (error) {
            console.error(error);
            setInsight('<h4>Erro na Análise</h4><p>Falha ao gerar insights. Verifique o console para mais detalhes.</p>');
        } finally {
            setIsLoading(false);
        }
    }, [assetData, timeframe]);

    return (
        <div className="bg-slate-800/50 p-6 rounded-2xl shadow-lg flex flex-col justify-between">
            <div className="flex-grow prose prose-invert prose-sm max-w-none text-slate-300 overflow-y-auto min-h-[120px]">
                {isLoading ? (
                    <div className="flex flex-col items-center justify-center h-full gap-4">
                        <LoadingSpinner />
                        <p className="text-slate-400">Analisando indicadores...</p>
                    </div>
                ) : (
                    <div dangerouslySetInnerHTML={{ __html: insight }} />
                )}
            </div>
            <button
                onClick={handleGenerateInsight}
                disabled={isLoading}
                className="mt-4 w-full flex items-center justify-center gap-2 bg-slate-600 text-white py-2 px-4 rounded-lg font-semibold hover:bg-slate-700 disabled:bg-slate-800 disabled:cursor-not-allowed transition-colors"
            >
                <SparklesIcon className="w-5 h-5" />
                <span>{isLoading ? 'Analisando...' : `Analisar Ativo (${timeframe})`}</span>
            </button>
        </div>
    );
};

export default AiInsightCard;