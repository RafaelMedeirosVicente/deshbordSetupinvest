import React from 'react';
import { ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, Brush } from 'recharts';
import { CandlestickData, CandlestickChartProps } from '../types';
import SignalLight from './SignalLight';

const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
        const data = payload[0].payload;
        const lineColor = data.ma ? (payload.find((p: any) => p.dataKey === 'ma')?.stroke || '#facc15') : 'transparent';
        
        return (
            <div className="bg-slate-700 p-3 border border-slate-600 rounded-md shadow-lg text-sm">
                <p className="label text-white font-bold">{`Hora: ${label}`}</p>
                <p className="text-slate-300">{`Abertura: ${data.open.toLocaleString('pt-BR')}`}</p>
                <p className="text-slate-300">{`Máximo: ${data.high.toLocaleString('pt-BR')}`}</p>
                <p className="text-slate-300">{`Mínimo: ${data.low.toLocaleString('pt-BR')}`}</p>
                <p className="text-slate-300">{`Fechamento: ${data.close.toLocaleString('pt-BR')}`}</p>
                {data.ma && (
                    <p style={{ color: lineColor }}>
                        {`Média Móvel (20): ${data.ma.toLocaleString('pt-BR')}`}
                    </p>
                )}
            </div>
        );
    }
    return null;
};

const CandlestickChart: React.FC<CandlestickChartProps> = ({ asset, data, timeframe, signal }) => {
    const processedData = data.map(d => ({
        ...d,
        bodyRange: [d.open, d.close].sort((a,b) => a-b),
        wickRange: [d.low, d.high]
    }));

    const yDomain = [
        (dataMin: number) => Math.floor(dataMin * 0.998),
        (dataMax: number) => Math.ceil(dataMax * 1.002)
    ] as const;
    
    const lineColor = asset === 'WINFUT' ? '#facc15' : '#94a3b8';

    return (
        <div className="relative bg-slate-800/50 p-6 rounded-2xl shadow-lg flex flex-col h-full min-h-[380px]">
            <SignalLight signal={signal} />
            <div className="flex flex-wrap justify-between items-center gap-4 mb-4">
                <h3 className="text-lg font-semibold text-white">Gráfico: {asset} ({timeframe})</h3>
            </div>
            <div className="flex-grow">
                <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={processedData} margin={{ top: 5, right: 20, left: 0, bottom: 40 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                        <XAxis 
                            dataKey="date" 
                            stroke="#94a3b8" 
                            fontSize={12} 
                            tickLine={false} 
                            axisLine={false} 
                            interval={0} // Brush will control visible ticks
                            tick={{ dy: 10 }} // Move ticks down a bit from chart
                        />
                        <YAxis 
                            stroke="#94a3b8" 
                            fontSize={12} 
                            tickLine={false} 
                            axisLine={false} 
                            domain={yDomain}
                            tickFormatter={(value) => typeof value === 'number' ? value.toLocaleString('pt-BR', {minimumFractionDigits: 0}) : value}
                            orientation="right"
                        />
                        <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(148, 163, 184, 0.1)' }} />
                        
                        <Bar dataKey="wickRange" barSize={1}>
                            {processedData.map((entry, index) => (
                                <Cell key={`cell-wick-${index}`} fill={entry.close >= entry.open ? '#10b981' : '#ef4444'} />
                            ))}
                        </Bar>
                        <Bar dataKey="bodyRange" barSize={8}>
                            {processedData.map((entry, index) => (
                                <Cell key={`cell-body-${index}`} fill={entry.close >= entry.open ? '#10b981' : '#ef4444'} />
                            ))}
                        </Bar>
                        <Line
                            type="monotone"
                            dataKey="ma"
                            stroke={lineColor}
                            strokeWidth={2}
                            dot={false}
                            name="Média Móvel (20)"
                        />
                        <Brush
                            dataKey="date"
                            height={30}
                            stroke="#64748b"
                            fill="rgba(71, 85, 105, 0.5)"
                            travellerWidth={10}
                            startIndex={Math.max(0, processedData.length - 30)}
                            endIndex={processedData.length -1}
                        >
                             <ComposedChart>
                                <Line type="monotone" dataKey="close" stroke="#94a3b8" dot={false} />
                            </ComposedChart>
                        </Brush>
                    </ComposedChart>
                </ResponsiveContainer>
            </div>
        </div>
    );
};

export default CandlestickChart;
