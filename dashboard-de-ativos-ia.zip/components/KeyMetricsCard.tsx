import React from 'react';
import { KeyMetricsCardProps } from '../types';

const MetricDisplay: React.FC<{ label: string; value: string | number }> = ({ label, value }) => (
    <div className="bg-slate-900/70 p-3 rounded-lg text-center flex flex-col justify-center min-h-[64px]">
        <p className="text-xs text-slate-400 truncate">{label}</p>
        <p className="text-sm font-semibold text-white">{typeof value === 'number' ? value.toLocaleString('pt-BR') : value}</p>
    </div>
);

const VariationGauge: React.FC<{ value: string }> = ({ value }) => {
    const variation = parseFloat(String(value).replace('%', '').replace(',', '.'));
    if (isNaN(variation)) {
        return <div className="bg-slate-900/70 rounded-lg flex items-center justify-center p-4 min-h-[100px]"><p className="text-slate-400">N/A</p></div>;
    }
    const isPositive = variation >= 0;
    
    // Map variation to a rotation from -90deg (far left) to +90deg (far right).
    // Let's say -2% is -90deg and +2% is +90deg for clamping visual range.
    const clampedVariation = Math.max(-2, Math.min(2, variation));
    const rotation = (clampedVariation / 2) * 90; // degrees
    
    const colorClass = isPositive ? 'text-green-400' : 'text-red-400';
    const pointerColorClass = isPositive ? 'bg-green-400' : 'bg-red-400';
    const trackColor = isPositive ? 'rgba(34, 197, 94, 0.4)' : 'rgba(239, 68, 68, 0.4)';


    return (
        <div className="bg-slate-900/70 p-4 rounded-lg flex flex-col items-center justify-center space-y-2">
            <div className="relative w-40 h-20">
                {/* The half-donut track */}
                <svg viewBox="0 0 36 18" className="w-full h-full">
                    <path
                        d="M 2 16 A 16 16 0 0 1 34 16"
                        fill="none"
                        stroke={trackColor}
                        strokeWidth="4"
                        strokeLinecap="round"
                        className="transition-all duration-500"
                    />
                </svg>
                 {/* The pointer */}
                <div 
                    className="absolute bottom-0 left-1/2 w-0.5 h-[55%] origin-bottom transition-transform duration-500 ease-out"
                    style={{ transform: `rotate(${rotation}deg)` }}
                >
                    <div className={`w-full h-full ${pointerColorClass} rounded-t-full`}></div>
                </div>
                 {/* Center Hub */}
                <div className="absolute bottom-[-4px] left-1/2 -translate-x-1/2 w-4 h-4 bg-slate-400 rounded-full border-4 border-slate-900/70"></div>
            </div>
            <div className="text-center">
                 <p className="text-xs text-slate-400">Variação</p>
                 <p className={`text-2xl font-bold ${colorClass}`}>{value}</p>
            </div>
        </div>
    );
};


const KeyMetricsCard: React.FC<KeyMetricsCardProps> = ({ data }) => {
    return (
        <div className="bg-slate-800/50 p-6 rounded-2xl shadow-lg">
            <h3 className="text-lg font-semibold text-white mb-4">Métricas Principais</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                 <div className="md:col-span-1 flex items-center justify-center">
                    <VariationGauge value={String(data['Variação'])} />
                 </div>
                 <div className="md:col-span-2 grid grid-cols-2 sm:grid-cols-3 gap-4">
                    <MetricDisplay label="Último" value={data['Último']} />
                    <MetricDisplay label="Abertura" value={data['Abertura']} />
                    <MetricDisplay label="Máximo" value={data['Máximo']} />
                    <MetricDisplay label="Mínimo" value={data['Mínimo']} />
                    <MetricDisplay label="Negócios" value={data['Negócios']} />
                    <MetricDisplay label="Ajuste" value={data['Ajuste']} />
                 </div>
            </div>
        </div>
    );
};

export default KeyMetricsCard;