import React from 'react';
import { StatCardProps } from '../types';

const StatCard: React.FC<StatCardProps> = ({ title, value, change, icon: Icon, color }) => {
  return (
    <div className="bg-slate-800/50 p-6 rounded-2xl shadow-lg flex flex-col gap-2 transform hover:scale-105 transition-transform duration-300">
      <div className="flex items-center justify-between text-slate-400">
        <span className="text-sm font-medium">{title}</span>
        <Icon className="w-5 h-5" />
      </div>
      <div>
        <h3 className="text-2xl font-bold text-white">{value}</h3>
        <p className={`text-xs ${color}`}>{change} do último mês</p>
      </div>
    </div>
  );
};

export default StatCard;
