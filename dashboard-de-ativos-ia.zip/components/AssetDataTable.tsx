import React, { useState } from 'react';
import { AssetData, AssetDataTableProps, TimeInterval } from '../types';
import { BarChart, Bar, ResponsiveContainer, Cell } from 'recharts';

// Sub-componente para o medidor de RSI
const RsiMeter: React.FC<{ value: string | number }> = ({ value }) => {
    const rsi = typeof value === 'string' ? parseFloat(value.replace(',', '.')) : value;
    if (isNaN(rsi)) return <div>N/A</div>;

    const percentage = Math.max(0, Math.min(100, rsi));
    let statusText: string, statusColor: string, bgColor: string;

    if (rsi < 30) {
        statusText = 'Sobrevendido';
        statusColor = 'text-green-400';
        bgColor = 'bg-green-500/60';
    } else if (rsi > 70) {
        statusText = 'Sobrecomprado';
        statusColor = 'text-red-400';
        bgColor = 'bg-red-500/60';
    } else {
        statusText = 'Tendência Neutra';
        statusColor = 'text-slate-300';
        bgColor = 'bg-slate-500/60';
    }

    return (
        <div className="bg-slate-900/70 p-4 rounded-lg flex flex-col justify-center">
            <div className="flex justify-between items-baseline mb-2">
                <p className="text-sm text-slate-400">IFR (RSI)</p>
                <p className={`text-lg font-bold ${statusColor}`}>{rsi.toFixed(1)}</p>
            </div>
            <div className="relative w-full h-2 bg-slate-700 rounded-full">
                <div className="absolute top-0 left-0 h-full w-[30%] bg-green-500/60 rounded-l-full"></div>
                <div className="absolute top-0 left-[30%] h-full w-[40%] bg-slate-500/60"></div>
                <div className="absolute top-0 left-[70%] h-full w-[30%] bg-red-500/60 rounded-r-full"></div>
                <div
                    className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-3 h-3 bg-white rounded-full border-2 border-slate-900 shadow-md"
                    style={{ left: `${percentage}%` }}
                    title={`RSI: ${rsi.toFixed(1)}`}
                ></div>
            </div>
            <p className={`text-center text-sm font-semibold mt-2 ${statusColor}`}>{statusText}</p>
        </div>
    );
};

// Sub-componente para o medidor de Volatilidade (True Range)
const VolatilityMeter: React.FC<{ tr: string | number; price: string | number }> = ({ tr, price }) => {
    const trValue = typeof tr === 'string' ? parseFloat(tr.replace(',', '.')) : tr;
    const priceValue = typeof price === 'string' ? parseFloat(price.replace('.', '').replace(',', '.')) : price;
    if (isNaN(trValue) || isNaN(priceValue) || priceValue === 0) return <div>N/A</div>;

    const percentage = (trValue / priceValue) * 100;
    const displayPercentage = Math.min(100, (percentage / 2) * 100); // Scale for visual

    let statusText: string, statusColor: string;
    if (percentage < 0.5) {
        statusText = 'Baixa Volatilidade';
        statusColor = 'text-red-400';
    } else if (percentage <= 1.2) {
        statusText = 'Volatilidade Média';
        statusColor = 'text-slate-300';
    } else {
        statusText = 'Alta Volatilidade';
        statusColor = 'text-green-400';
    }

    return (
        <div className="bg-slate-900/70 p-4 rounded-lg flex flex-col justify-center">
            <div className="flex justify-between items-baseline mb-2">
                <p className="text-sm text-slate-400">True Range (Vol.)</p>
                <p className={`text-lg font-bold ${statusColor}`}>{trValue.toLocaleString('pt-BR')}</p>
            </div>
            <div className="relative w-full h-2 bg-slate-700 rounded-full">
                <div className="absolute top-0 left-0 h-full w-[30%] bg-red-500/60 rounded-l-full"></div>
                <div className="absolute top-0 left-[30%] h-full w-[40%] bg-slate-500/60"></div>
                <div className="absolute top-0 left-[70%] h-full w-[30%] bg-green-500/60 rounded-r-full"></div>
                <div
                    className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-3 h-3 bg-white rounded-full border-2 border-slate-900 shadow-md"
                    style={{ left: `${displayPercentage}%` }}
                    title={`Volatilidade: ${percentage.toFixed(2)}%`}
                ></div>
            </div>
            <p className={`text-center text-sm font-semibold mt-2 ${statusColor}`}>{statusText}</p>
        </div>
    );
};

// Sub-componente para o indicador VWAP
const VwapIndicator: React.FC<{ vwap: string | number; price: string | number }> = ({ vwap, price }) => {
    const vwapValue = typeof vwap === 'string' ? parseFloat(vwap.replace('.', '').replace(',', '.')) : vwap;
    const priceValue = typeof price === 'string' ? parseFloat(price.replace('.', '').replace(',', '.')) : price;
    if (isNaN(vwapValue) || isNaN(priceValue)) return <div>N/A</div>;

    const isAbove = priceValue > vwapValue;
    const statusText = isAbove ? 'Acima do VWAP' : 'Abaixo do VWAP';
    const statusColor = isAbove ? 'text-green-400' : 'text-red-400';
    const markerColor = isAbove ? 'bg-green-400' : 'bg-red-400';

    const diff = Math.abs(priceValue - vwapValue);
    const range = vwapValue * 0.005; // Visual range of +-0.5%
    const position = 50 + ( (priceValue - vwapValue) / range ) * 50;
    const markerPosition = Math.max(5, Math.min(95, position));

    return (
        <div className="bg-slate-900/70 p-4 rounded-lg flex flex-col justify-center">
            <div className="flex justify-between items-baseline mb-2">
                 <p className="text-sm text-slate-400">Preço vs. VWAP</p>
                 <p className={`text-lg font-bold ${statusColor}`}>{priceValue.toLocaleString('pt-BR')}</p>
            </div>
            <div className="relative w-full py-2">
                <div className="h-0.5 bg-slate-500 border-t border-b border-dashed border-slate-600"></div>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-xs text-slate-400 bg-slate-900/70 px-1">VWAP {vwapValue.toLocaleString('pt-BR')}</div>
                <div className={`absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-3 h-3 ${markerColor} rounded-full border-2 border-slate-900`}
                     style={{ left: `${markerPosition}%` }}
                     title={`Diferença: ${diff.toFixed(2)}`}
                ></div>
            </div>
            <p className={`text-center text-sm font-semibold mt-2 ${statusColor}`}>{statusText}</p>
        </div>
    );
};

// Sub-componente para o gráfico de Volume
const MiniVolumeChart: React.FC<{ volume: string | number; asset: string; timeframe: TimeInterval }> = ({ volume, asset, timeframe }) => {
    // Gerar dados mock para o gráfico com base no ativo e no tempo
    const generateVolumeData = () => {
        return Array.from({ length: 20 }, (_, i) => ({
            name: `T${i}`,
            vol: Math.random() * 1000 + 500,
            type: Math.random() > 0.5 ? 'buy' : 'sell'
        }));
    };
    
    const data = generateVolumeData();

    return (
        <div className="bg-slate-900/70 p-4 rounded-lg flex flex-col justify-center">
            <div className="flex justify-between items-baseline mb-2">
                <p className="text-sm text-slate-400">Volume ({timeframe})</p>
                <p className="text-lg font-bold text-white">{volume.toLocaleString('pt-BR')}</p>
            </div>
            <div className="w-full h-16">
                 <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={data}>
                        <Bar dataKey="vol">
                             {data.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.type === 'buy' ? 'rgba(34, 197, 94, 0.6)' : 'rgba(239, 68, 68, 0.6)'} />
                            ))}
                        </Bar>
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </div>
    );
};


const AssetDataTable: React.FC<AssetDataTableProps> = ({ data, timeframe }) => {
    return (
        <div className="bg-slate-800/50 p-6 rounded-2xl shadow-lg">
            <h3 className="text-lg font-semibold text-white mb-4">Dados Detalhados</h3>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <RsiMeter value={data['IFR (RSI)']} />
                <VolatilityMeter tr={data['True Range']} price={data['Último']} />
                <VwapIndicator vwap={data.VWAP} price={data['Último']} />
                <MiniVolumeChart volume={data.Volume} asset={data.Asset} timeframe={timeframe}/>
            </div>
        </div>
    );
};

export default AssetDataTable;