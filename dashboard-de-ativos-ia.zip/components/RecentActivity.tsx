import React from 'react';
import { ActivityItem } from '../types';

const activityItems: ActivityItem[] = [
  { id: 1, name: 'Olivia Martin', email: 'olivia.martin@email.com', amount: '+$1,999.00', status: 'Success' },
  { id: 2, name: 'Jackson Lee', email: 'jackson.lee@email.com', amount: '+$39.00', status: 'Success' },
  { id: 3, name: 'Isabella Nguyen', email: 'isabella.nguyen@email.com', amount: '+$299.00', status: 'Pending' },
  { id: 4, name: 'William Kim', email: 'will@email.com', amount: '-$99.00', status: 'Failed' },
  { id: 5, name: 'Sofia Davis', email: 'sofia.davis@email.com', amount: '+$39.00', status: 'Success' },
];

const StatusBadge: React.FC<{ status: 'Success' | 'Pending' | 'Failed' }> = ({ status }) => {
    const baseClasses = "px-2 py-1 text-xs font-medium rounded-full";
    const statusClasses = {
        Success: "bg-green-500/20 text-green-400",
        Pending: "bg-yellow-500/20 text-yellow-400",
        Failed: "bg-red-500/20 text-red-400"
    };
    return <span className={`${baseClasses} ${statusClasses[status]}`}>{status}</span>
}

const RecentActivity: React.FC = () => {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm text-left text-slate-400">
        <thead className="text-xs text-slate-500 uppercase">
          <tr>
            <th scope="col" className="px-6 py-3">Customer</th>
            <th scope="col" className="px-6 py-3">Status</th>
            <th scope="col" className="px-6 py-3 text-right">Amount</th>
          </tr>
        </thead>
        <tbody>
          {activityItems.map((item) => (
            <tr key={item.id} className="border-b border-slate-700 hover:bg-slate-700/50">
              <td className="px-6 py-4">
                <div className="font-medium text-white">{item.name}</div>
                <div className="text-slate-500">{item.email}</div>
              </td>
              <td className="px-6 py-4">
                <StatusBadge status={item.status} />
              </td>
              <td className="px-6 py-4 text-right font-medium text-white">{item.amount}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default RecentActivity;