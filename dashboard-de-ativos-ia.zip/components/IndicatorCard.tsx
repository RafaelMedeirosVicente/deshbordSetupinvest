import React from 'react';
import { IndicatorCardProps } from '../types';

const AdxMeter: React.FC<{ value: number }> = ({ value }) => {
    const adx = Math.max(0, Math.min(100, value));
    const percentage = adx;

    let statusText: string;
    let statusColor: string;
    
    if (adx < 20) {
        statusText = 'Tendência Fraca';
        statusColor = 'text-red-400';
    } else if (adx <= 25) {
        statusText = 'Tendência Neutra';
        statusColor = 'text-slate-300';
    } else {
        statusText = 'Tendência Forte';
        statusColor = 'text-green-400';
    }

    return (
        <div className="bg-slate-900/70 p-4 rounded-lg flex flex-col justify-center">
            <div className="flex justify-between items-baseline mb-2">
                <p className="text-sm text-slate-400">ADX (Força)</p>
                <p className={`text-lg font-bold ${statusColor}`}>{adx.toFixed(1)}</p>
            </div>
            <div className="relative w-full h-2 bg-slate-700 rounded-full">
                <div className="absolute top-0 left-0 h-full w-[20%] bg-red-500/60 rounded-l-full"></div>
                <div className="absolute top-0 left-[20%] h-full w-[5%] bg-slate-500/60"></div>
                <div className="absolute top-0 left-[25%] h-full w-[75%] bg-green-500/60 rounded-r-full"></div>
                <div
                    className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-3 h-3 bg-white rounded-full border-2 border-slate-900 shadow-md"
                    style={{ left: `${percentage}%` }}
                    title={`ADX: ${adx.toFixed(1)}`}
                ></div>
            </div>
            <p className={`text-center text-sm font-semibold mt-2 ${statusColor}`}>{statusText}</p>
        </div>
    );
};

const ForceIndexMeter: React.FC<{ value1: number; value2: number }> = ({ value1, value2 }) => {
    const maxVisValue = 10000000;
    const value1Percent = (Math.abs(value1) / maxVisValue) * 100;
    const isPositive = value1 >= 0;

    let interpretation = '';
    let interpretationColor = 'text-slate-300';
    if (Math.abs(value1) < 100000) {
        interpretation = 'Equilíbrio de Forças';
    } else if (isPositive) {
        interpretation = Math.abs(value1) > 5000000 ? 'Forte Pressão de Compra' : 'Pressão de Compra';
    } else {
        interpretation = Math.abs(value1) > 5000000 ? 'Forte Pressão de Venda' : 'Pressão de Venda';
    }
    
    if (isPositive) {
      interpretationColor = 'text-green-400';
    } else {
      interpretationColor = 'text-red-400';
    }
    if (Math.abs(value1) < 100000) {
      interpretationColor = 'text-slate-300';
    }


    const formatNumber = (num: number) => num.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

    return (
        <div className="bg-slate-900/70 p-4 rounded-lg flex flex-col justify-center">
            <p className="text-sm text-slate-400 mb-2">Índice de Força</p>
            
            <div className="flex items-center w-full my-2">
                <div className="flex-1 flex justify-end">
                    {!isPositive && (
                         <div 
                            className="h-3 bg-red-500/80 rounded-l-md transition-all duration-300"
                            style={{ width: `${Math.min(100, value1Percent)}%` }}
                        ></div>
                    )}
                </div>
                <div className="w-0.5 h-5 bg-slate-500" />
                <div className="flex-1 flex justify-start">
                     {isPositive && (
                         <div 
                            className="h-3 bg-green-500/80 rounded-r-md transition-all duration-300"
                            style={{ width: `${Math.min(100, value1Percent)}%` }}
                        ></div>
                    )}
                </div>
            </div>

            <div className="flex justify-between text-xs mt-1 px-1">
                <span className={value1 >= 0 ? 'text-green-400' : 'text-red-400'}>{formatNumber(value1)}</span>
                <span className={value2 >= 0 ? 'text-green-400' : 'text-red-400'}>{formatNumber(value2)}</span>
            </div>

            <p className={`text-center text-sm font-semibold mt-2 ${interpretationColor}`}>{interpretation}</p>
        </div>
    );
};

const BullBearPowerMeter: React.FC<{ bullPower: number; bearPower: number }> = ({ bullPower, bearPower }) => {
    const maxAbsValue = Math.max(Math.abs(bullPower), Math.abs(bearPower), 1); 
    const bullWidth = (Math.max(0, bullPower) / maxAbsValue) * 100;
    const bearWidth = (Math.max(0, -bearPower) / maxAbsValue) * 100;

    let interpretation = '';
    let interpretationColor = 'text-slate-300';

    if (bullPower > 0 && bearPower > 0) {
        interpretation = 'Pressão de Alta Muito Forte';
        interpretationColor = 'text-green-400';
    } else if (bullPower < 0 && bearPower < 0) {
        interpretation = 'Pressão de Baixa Muito Forte';
        interpretationColor = 'text-red-400';
    } else if (bullPower > Math.abs(bearPower)) {
        interpretation = 'Força Compradora Dominante';
        interpretationColor = 'text-green-400';
    } else {
        interpretation = 'Força Vendedora Dominante';
        interpretationColor = 'text-red-400';
    }

    const formatNumber = (num: number) => num.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

    return (
      <div className="bg-slate-900/70 p-4 rounded-lg sm:col-span-2 flex flex-col justify-center">
        <p className="text-sm text-slate-400 mb-2">Força Touro vs. Urso (Bull/Bear Power)</p>
        
        <div className="flex items-center w-full my-2">
            <div className="flex-1 flex justify-end">
                <div 
                    className="h-3 bg-red-500/80 rounded-l-md"
                    style={{ width: `${bearWidth}%` }}
                    title={`Bear Power: ${formatNumber(bearPower)}`}
                ></div>
            </div>
            <div className="w-0.5 h-5 bg-slate-500" />
            <div className="flex-1 flex justify-start">
                 <div 
                    className="h-3 bg-green-500/80 rounded-r-md"
                    style={{ width: `${bullWidth}%` }}
                    title={`Bull Power: ${formatNumber(bullPower)}`}
                ></div>
            </div>
        </div>

        <div className="flex justify-between text-xs mt-1 px-1">
            <span className="text-red-400 font-semibold">{formatNumber(bearPower)}</span>
            <span className="text-green-400 font-semibold">{formatNumber(bullPower)}</span>
        </div>

        <p className={`text-center text-sm font-semibold mt-2 ${interpretationColor}`}>{interpretation}</p>
      </div>
    );
};


const IndicatorCard: React.FC<IndicatorCardProps> = ({ title, data }) => {
    return (
        <div className="bg-slate-800/50 p-6 rounded-2xl shadow-lg">
            <h3 className="text-lg font-semibold text-white mb-4">{title}</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <AdxMeter value={data.ADX} />
                <ForceIndexMeter value1={data['Force Index'].value1} value2={data['Force Index'].value2} />
                <BullBearPowerMeter bullPower={data['Bull Power']} bearPower={data['Bear Power']} />
            </div>
        </div>
    );
};

export default IndicatorCard;