import React, { useState } from 'react';
import { ChartBarIcon } from './constants';
import { AssetData, TimeInterval, CandlestickData, MarketSignal } from './types';
import CandlestickChart from './components/CandlestickChart';
import IndicatorCard from './components/IndicatorCard';
import AiInsightCard from './components/AiInsightCard';
import KeyMetricsCard from './components/KeyMetricsCard';
import AssetDataTable from './components/AssetDataTable';
import { allWinfutData, allWdofutData, allMockCandleData } from './services/mockDataService';

const calculateMarketSignal = (data: AssetData): MarketSignal => {
    let buyScore = 0;
    let sellScore = 0;

    const parseNum = (val: string | number) => {
        if (typeof val === 'number') return val;
        return parseFloat(String(val).replace(/\./g, '').replace(',', '.'));
    }
    
    const price = parseNum(data['Último']);
    const vwap = parseNum(data.VWAP);
    const rsi = parseNum(data['IFR (RSI)']);
    const adx = data.ADX;
    const tr = parseNum(data['True Range']);
    
    if ([price, vwap, rsi, adx, tr].some(isNaN)) return 'neutral';

    if (price > vwap) buyScore += 1.5;
    else sellScore += 1.5;

    if (rsi > 60) buyScore += 1;
    else if (rsi < 40) sellScore += 1;

    const volatilityPercent = (tr / price) * 100;
    const isHighVolatility = volatilityPercent > (data.Asset === 'WINFUT' ? 0.8 : 1.5);

    if (adx > 25 && isHighVolatility) {
        if (buyScore > sellScore) buyScore += 1;
        else if (sellScore > buyScore) sellScore += 1;
    }
    
    if (buyScore - sellScore > 1) return 'buy';
    if (sellScore - buyScore > 1) return 'sell';
    
    return 'neutral';
};

interface HeaderProps {
    lastUpdateDate: string;
    lastUpdateTime: string;
    activeTimeframe: TimeInterval;
    onTimeframeChange: (timeframe: TimeInterval) => void;
}

const timeIntervals: { label: string; value: TimeInterval }[] = [ { label: '1m', value: '1m' }, { label: '5m', value: '5m' }, { label: '15m', value: '15m' }, { label: '60m', value: '60m' }];

const Header: React.FC<HeaderProps> = ({ lastUpdateDate, lastUpdateTime, activeTimeframe, onTimeframeChange }) => {
    return (
        <header className="p-6 flex flex-col items-center text-center gap-4">
            <div className="flex items-center gap-4">
                <div className="bg-slate-800 p-2 rounded-lg flex-shrink-0">
                    <ChartBarIcon className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-white">Dashboard SetupInvet com IA</h2>
            </div>
             <div className="flex items-baseline gap-3 text-slate-400">
                <p>Bem-vindo(a) de volta, veja o que está acontecendo.</p>
                <span className="text-slate-600">|</span>
                <p>Última atualização: {lastUpdateDate} às {lastUpdateTime}</p>
            </div>
            <div className="flex gap-1 bg-slate-800/50 p-1 rounded-lg">
                {timeIntervals.map(interval => (
                     <button 
                        key={interval.value}
                        onClick={() => onTimeframeChange(interval.value)}
                        className={`px-4 py-1.5 text-sm font-semibold rounded-md transition-colors ${activeTimeframe === interval.value ? 'bg-slate-600 text-white' : 'text-slate-300 hover:bg-slate-700'}`}>
                        {interval.label}
                    </button>
                ))}
            </div>
        </header>
    );
};


const App: React.FC = () => {
  const [timeframe, setTimeframe] = useState<TimeInterval>('5m');
  const lastUpdate = new Date();
  const lastUpdateDate = lastUpdate.toLocaleDateString('pt-BR');
  const lastUpdateTime = lastUpdate.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  
  const currentWinfutData = allWinfutData[timeframe];
  const currentWdofutData = allWdofutData[timeframe];
  const currentWinfutCandleData = allMockCandleData['WINFUT'][timeframe];
  const currentWdofutCandleData = allMockCandleData['WDOFUT'][timeframe];

  const winfutSignal = calculateMarketSignal(currentWinfutData);
  const wdofutSignal = calculateMarketSignal(currentWdofutData);

  return (
    <div className="bg-black min-h-screen text-white">
      <main className="flex-1 flex flex-col">
        <Header
          lastUpdateDate={lastUpdateDate}
          lastUpdateTime={lastUpdateTime}
          activeTimeframe={timeframe}
          onTimeframeChange={setTimeframe}
        />
        <div className="flex-grow p-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* WINFUT Column */}
          <div className="flex flex-col gap-6">
            <CandlestickChart asset="WINFUT" data={currentWinfutCandleData} timeframe={timeframe} signal={winfutSignal} />
            <KeyMetricsCard data={currentWinfutData} />
            <IndicatorCard title="Indicadores WINFUT" data={currentWinfutData} />
            <AssetDataTable data={currentWinfutData} timeframe={timeframe} />
            <AiInsightCard assetData={currentWinfutData} timeframe={timeframe} />
          </div>
          {/* WDOFUT Column */}
          <div className="flex flex-col gap-6">
            <CandlestickChart asset="WDOFUT" data={currentWdofutCandleData} timeframe={timeframe} signal={wdofutSignal} />
            <KeyMetricsCard data={currentWdofutData} />
            <IndicatorCard title="Indicadores WDOFUT" data={currentWdofutData} />
            <AssetDataTable data={currentWdofutData} timeframe={timeframe} />
            <AiInsightCard assetData={currentWdofutData} timeframe={timeframe} />
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;